//Would love some help/going over this header class and connecting it to my 
//source.cpp, as I am having some strange errors I can't seem to troubleshoot.

//Header file for Customer class

//Original Customer Class
/*namespace H {
    class Customer {

    private:
        string custId;
        string custName;
        Customer* related;

    public:
        //default constructor
        Customer() {
            custId = 123;
            custName = "First Last";
            related = nullptr;
        }

        //constructor with both fields
        Customer(string ID, string name) {
            custId = ID;
            custName = name;
            related = nullptr;
        }

        //constructor just id
        Customer(string ID) {
            custId = ID;
            related = nullptr;
        }

        //constructor just name
        Customer(string name) {
            custName = name;
            related = nullptr;
        }

        //get ID method
        string getId() {
            return custId;
        }

        //get name method
        string getName() {
            return custName;
        }

        //set id method
        void setId(string Id) {
            custId = Id;
            return;
        }

        //set name method
        void setName(string name) {
            custName = name;
            return;
        }

        //set related method
        void setRelated(Customer cust) {
            related = &cust;
        }

        //print method
        virtual void printCustomer() {
            cout << "Customer ID is: " << getId() << endl;
            cout << "Customer Name is: " << getName() << endl;
            cout << "Related Customer name is: " << endl; //fix this line
        }
    };
}*/
